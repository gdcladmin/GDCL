<?php

    $database= new mysqli("localhost","root","","vidya");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>